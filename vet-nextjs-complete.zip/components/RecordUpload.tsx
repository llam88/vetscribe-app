"use client"
import { useState } from "react"
import TemplatesPicker from "@/components/TemplatesPicker"
import { NoteTemplate } from "@/data/templates"

export default function RecordUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [transcription, setTranscription] = useState("")
  const [note, setNote] = useState("")
  const [summary, setSummary] = useState("")
  const [loading, setLoading] = useState(false)
  const [template, setTemplate] = useState<NoteTemplate | null>(null)
  const [patientInfo, setPatientInfo] = useState({
    name: "", species: "", breed: "", age: "", sex: "", weight: "", owner: ""
  })

  async function handleTranscribe() {
    if (!file) return
    setLoading(true)
    try {
      const fd = new FormData()
      fd.append("audio", file)
      const tRes = await fetch("/api/transcribe", { method: "POST", body: fd })
      const tJson = await tRes.json()
      setTranscription(tJson.transcription || "")
    } finally {
      setLoading(false)
    }
  }

  async function handleNote() {
    setLoading(true)
    try {
      const sRes = await fetch("/api/generate-soap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcription, patientInfo, visitType: "General", template })
      })
      const sJson = await sRes.json()
      setNote(sJson.note || "")
    } finally {
      setLoading(false)
    }
  }

  async function handleSummary() {
    setLoading(true)
    try {
      const sRes = await fetch("/api/client-summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcription })
      })
      const sJson = await sRes.json()
      setSummary(sJson.summary || "")
    } finally {
      setLoading(false)
    }
  }

  async function exportPdf(title: string, content: string) {
    const res = await fetch("/api/export-pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content })
    })
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${title.replace(/[^a-z0-9]/gi,"_").toLowerCase()}.pdf`
    a.click()
    URL.revokeObjectURL(url)
  }

  function field(name: keyof typeof patientInfo, label?: string) {
    return (
      <div>
        <label className="block text-xs text-gray-600">{label || name}</label>
        <input
          className="border rounded p-2 w-full"
          value={(patientInfo as any)[name]}
          onChange={e => setPatientInfo(p => ({ ...p, [name]: e.target.value }))}
          placeholder={label || name}
        />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="p-3 border rounded bg-yellow-50 text-sm">
        Demo only — do not upload PHI. Audio is sent to OpenAI Whisper API for transcription.
      </div>

      <div className="p-3 border rounded">
        <label className="block text-sm font-medium mb-1">Audio file</label>
        <input type="file" accept="audio/*" onChange={e => setFile(e.target.files?.[0] || null)} />
        <button
          className="ml-3 px-3 py-2 rounded bg-black text-white disabled:opacity-50"
          onClick={handleTranscribe}
          disabled={!file || loading}
        >
          {loading ? "Transcribing..." : "Transcribe"}
        </button>
      </div>

      <div className="p-3 border rounded grid gap-2 sm:grid-cols-2">
        {field("name", "Name")}
        {field("owner", "Owner")}
        {field("species", "Species")}
        {field("breed", "Breed")}
        {field("sex", "Sex")}
        {field("age", "Age")}
        {field("weight", "Weight")}
      </div>

      <div className="p-3 border rounded">
        <label className="block text-sm font-medium mb-1">Pick a template</label>
        <TemplatesPicker onChange={t => setTemplate(t)} />
      </div>

      <div className="p-3 border rounded">
        <label className="block text-sm font-medium mb-1">Transcript</label>
        <textarea className="w-full border rounded p-2 min-h-[120px]" value={transcription} onChange={e => setTranscription(e.target.value)} />
        <div className="mt-2 flex gap-2">
          <button className="px-3 py-2 rounded bg-black text-white disabled:opacity-50" onClick={handleNote} disabled={!transcription || loading}>
            {loading ? "Generating..." : "Generate Note"}
          </button>
          <button className="px-3 py-2 rounded border disabled:opacity-50" onClick={handleSummary} disabled={!transcription || loading}>
            {loading ? "Working..." : "Client Summary"}
          </button>
        </div>
      </div>

      <div className="p-3 border rounded">
        <label className="block text-sm font-medium mb-1">Generated Note</label>
        <textarea className="w-full border rounded p-2 min-h-[200px]" value={note} onChange={e => setNote(e.target.value)} />
        <div className="mt-2 flex gap-2">
          <button className="px-3 py-2 rounded border" onClick={() => navigator.clipboard.writeText(note)}>Copy</button>
          <a className="px-3 py-2 rounded border" href={`data:text/plain;charset=utf-8,${encodeURIComponent(note)}`} download="note.txt">Download .txt</a>
          <button className="px-3 py-2 rounded border" onClick={() => exportPdf("Visit_Note", note)}>Download PDF</button>
        </div>
      </div>

      <div className="p-3 border rounded">
        <label className="block text-sm font-medium mb-1">Client Summary</label>
        <textarea className="w-full border rounded p-2 min-h-[140px]" value={summary} onChange={e => setSummary(e.target.value)} />
        <div className="mt-2 flex gap-2">
          <button className="px-3 py-2 rounded border" onClick={() => navigator.clipboard.writeText(summary)}>Copy</button>
          <a className="px-3 py-2 rounded border" href={`data:text/plain;charset=utf-8,${encodeURIComponent(summary)}`} download="summary.txt">Download .txt</a>
          <button className="px-3 py-2 rounded border" onClick={() => exportPdf("Client_Summary", summary)}>Download PDF</button>
        </div>
      </div>
    </div>
  )
}
