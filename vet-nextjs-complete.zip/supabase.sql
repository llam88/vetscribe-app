-- Create a minimal profiles table to link auth users to rows
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  created_at timestamp with time zone default now()
);

-- Keep up-to-date on signups (optional trigger can be added).

-- Patients table
create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  name text not null,
  species text,
  breed text,
  sex text,
  age text,
  weight text,
  owner text,
  notes text
);

-- Enable Row Level Security
alter table public.patients enable row level security;

-- RLS policies: user can manage only their rows
create policy "patients_select_own"
  on public.patients
  for select
  using (auth.uid() = user_id);

create policy "patients_insert_own"
  on public.patients
  for insert
  with check (auth.uid() = user_id);

create policy "patients_update_own"
  on public.patients
  for update
  using (auth.uid() = user_id);

create policy "patients_delete_own"
  on public.patients
  for delete
  using (auth.uid() = user_id);
