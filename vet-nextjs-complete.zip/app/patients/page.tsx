import { redirect } from "next/navigation"
import { createClientServer } from "@/lib/supabase"
import PatientsForm from "@/components/PatientsForm"
import PatientsTable from "@/components/PatientsTable"

export default async function PatientsPage() {
  const sb = createClientServer()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) redirect("/sign-in")

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Patients</h1>
      <PatientsForm onSaved={() => { /* table auto-reloads via state */ }} />
      <PatientsTable />
    </div>
  )
}
