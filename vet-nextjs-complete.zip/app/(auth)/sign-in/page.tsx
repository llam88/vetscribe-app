"use client"
import { useState } from "react"
import { createClientBrowser } from "@/lib/supabase"

export default function SignInPage() {
  const sb = createClientBrowser()
  const [email, setEmail] = useState("")
  const [sent, setSent] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function sendMagic() {
    setError(null)
    const { error } = await sb.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin + "/dashboard" } })
    if (error) setError(error.message)
    else setSent(true)
  }

  return (
    <div className="max-w-sm mx-auto p-6">
      <h1 className="text-xl font-semibold mb-4">Sign in</h1>
      {sent ? (
        <p>Check your email for a magic link.</p>
      ) : (
        <>
          <input
            className="border rounded w-full p-2 mb-3"
            placeholder="you@clinic.com"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
          <button className="px-4 py-2 rounded bg-black text-white" onClick={sendMagic}>
            Send magic link
          </button>
          {error && <p className="text-red-600 mt-2">{error}</p>}
        </>
      )}
    </div>
  )
}
