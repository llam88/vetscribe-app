import { NextRequest } from "next/server"
import PDFDocument from "pdfkit"

export const runtime = "nodejs"

export async function POST(req: NextRequest) {
  const { title = "Note", content = "" } = await req.json()
  const doc = new PDFDocument({ margin: 50 })
  const chunks: Uint8Array[] = []

  return new Response(
    new ReadableStream({
      start(controller) {
        doc.on("data", (chunk) => {
          chunks.push(chunk)
          controller.enqueue(chunk)
        })
        doc.on("end", () => controller.close())

        doc.fontSize(18).text(title, { underline: true })
        doc.moveDown()
        doc.fontSize(11).text(content, { align: "left" })
        doc.end()
      },
    }),
    {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}.pdf"`,
      },
    }
  )
}
