import { redirect } from "next/navigation"
import { createClientServer } from "@/lib/supabase"
import RecordUpload from "@/components/RecordUpload"

export default async function RecordPage() {
  const sb = createClientServer()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) redirect("/sign-in")

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-xl font-semibold mb-4">Record & Transcribe</h1>
      <RecordUpload />
    </div>
  )
}
