import { redirect } from "next/navigation"
import { createClientServer } from "@/lib/supabase"

export default async function Dashboard() {
  const sb = createClientServer()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) redirect("/sign-in")

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold mb-4">Dashboard</h1>
      <div className="grid gap-4 sm:grid-cols-3">
        <a className="border rounded p-4 hover:bg-gray-50" href="/record">Record & Transcribe</a>
        <a className="border rounded p-4 hover:bg-gray-50" href="/patients">Patients</a>
        <a className="border rounded p-4 hover:bg-gray-50" href="/templates">Templates</a>
      </div>
    </div>
  )
}
